
<!DOCTYPE html>
<html>
<head>
<title> Mr.Chip21 || UNMASKED</title>
<link rel="icon"  type="img/gif" href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQySbF6L3_Ulc2ldJbVIckKRoVKAsNwnhyG8IlJI6MwFHyyzfV2">
<br>
<br><center><p><font color="white" size="14 "> Idiot BlackHat </font></center>
</head>
<body>
<div class="box">
	
 <center><p>This site is stamp by Mr.Chip21</p>
  <p> 
Dimana keadilan yang sesungguhnya , <p>apakah rakyat miskin tidak pantas mendapat ampun?<p>
apakah koruptor pantas di bebaskan? 
<p> rakyat jelata memang selalu salah di mata mereka ! Tapi kami tidak akan diam !!
	<p></center>
	<br>


<br>
	<br>
		<br>
	<br>
		<br>
<br>
		<br>
	<br>
<br>
	<br>
<footer><center><font color="white" size="4">Shootz : </font><font color="white" size="4"><marquee behavior="scroll" direction="left" scrollamount="10" width="25%">|| ApriliX02 || Cy#b3r00t || Mr.An4rk! || Mr.xBaraKuda || Mr.Cakil || 4LM05TH3V!L || Mr.Mr Cvl || Temboxxxz || || 4RCH!VER || Mr.TRINITY || ZORLAX || TN72 || Cl4yZero || CROPz || Mr.BL4CK0UT || Mana Ku Tau || Fhander-X || Dark'Alone || AND YOU ADMIN :)</marquee></center></footer>


  </div>
  <center><img src="http://www.voa-islam.com/photos4/rojul/garudaluka-rle5aa.%5B1%5D.jpg" height="600px" width="800px"></center>
<style type="text/css">
body{
  background-color: #000000;
  cursor: none;
}
.box{
  position: absolute;
  top: 300px;
  left: 100px;
}
p{
  color: #D9D5D5; 
  font-family: "Courier";
  font-size: 20px;
  margin: 10px 0 0 10px;
  white-space: nowrap;
  overflow: hidden;
  width: 30em;
  animation: type 3s steps(60, end); 
}

p:nth-child(2){
  animation: type2 6s steps(60, end);
}

p a{
  color: #D9D5D5;
  text-decoration: none;
}

span{
  animation: blink 1s infinite;
}

@keyframes type{ 
  from { width: 0; } 
} 

@keyframes type2{
  0%{width: 0;}
  50%{width: 0;}
  100%{ width: 100; } 
} 

@keyframes blink{
  to{opacity: .0;}
}

::selection{
  background: black;
}
</style>
</body>
</html>
<font color="black">hacked</font>
<body oncontextmenu="return false;" onkeydown="return false;" onmousedown="return false;" bgcolor="black" onload="type_text()">
	
<!-- <audio source="mp3" src="https://a.top4top.net/m_833scjqi1.mp3" type="audio/mp3" autoplay="autoplay" loop="loop"></audio> -->
	
<audio source="mp3" src="https://a.top4top.net/m_833scjqi1.mp3" type="audio/mp3" autoplay="autoplay" loop="loop"></audio>
		
<center>
